
package SleepTracker;

import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.sql.*;
import java.text.SimpleDateFormat;
import javax.swing.JOptionPane;
import java.util.Date;
import javax.swing.Timer;



public class SleepTrackerFrame extends javax.swing.JFrame {
String dbUrl = "jdbc:mysql://localhost:3306/sqt";
        String dbUsername = "root";
        String dbPassword = "";
  private int lastDisplayedRecordId = 0; 
    public SleepTrackerFrame() {
        initComponents();
        
        times();
         dt();
    }

    
    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        jPanel1 = new javax.swing.JPanel();
        submitButton = new javax.swing.JButton();
        Backbtn = new javax.swing.JButton();
        sleepDurationLabel = new javax.swing.JLabel();
        wakeUpLabel = new javax.swing.JLabel();
        refreshedLabel = new javax.swing.JLabel();
        restfulSleepLabel = new javax.swing.JLabel();
        wakeUpTextField = new javax.swing.JTextField();
        sleepDurationTextField1 = new javax.swing.JTextField();
        noRadioButton = new javax.swing.JRadioButton();
        yesRadioButton = new javax.swing.JRadioButton();
        refreshedSlider = new javax.swing.JSlider();
        displayButton = new javax.swing.JButton();
        I_date = new javax.swing.JLabel();
        I_time = new javax.swing.JLabel();

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);

        jPanel1.setBackground(new java.awt.Color(204, 255, 204));
        jPanel1.setBorder(javax.swing.BorderFactory.createTitledBorder(new javax.swing.border.MatteBorder(null), "Sleep Quality Tracker", javax.swing.border.TitledBorder.DEFAULT_JUSTIFICATION, javax.swing.border.TitledBorder.DEFAULT_POSITION, new java.awt.Font("Segoe UI", 1, 18))); // NOI18N
        jPanel1.setForeground(new java.awt.Color(102, 255, 51));

        submitButton.setFont(new java.awt.Font("Segoe UI", 1, 14)); // NOI18N
        submitButton.setText("Submit");
        submitButton.setBorder(new javax.swing.border.SoftBevelBorder(javax.swing.border.BevelBorder.RAISED));
        submitButton.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                submitButtonActionPerformed(evt);
            }
        });

        Backbtn.setFont(new java.awt.Font("Segoe UI", 1, 14)); // NOI18N
        Backbtn.setText("Back");
        Backbtn.setBorder(new javax.swing.border.SoftBevelBorder(javax.swing.border.BevelBorder.RAISED));
        Backbtn.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                BackbtnActionPerformed(evt);
            }
        });

        sleepDurationLabel.setFont(new java.awt.Font("Arial", 1, 14)); // NOI18N
        sleepDurationLabel.setText("How long did you sleep?");

        wakeUpLabel.setFont(new java.awt.Font("Arial", 1, 14)); // NOI18N
        wakeUpLabel.setText("Did you wake up in the night and how long for?");

        refreshedLabel.setFont(new java.awt.Font("Arial", 1, 14)); // NOI18N
        refreshedLabel.setText("How refreshed do you feel upon waking up?");

        restfulSleepLabel.setFont(new java.awt.Font("Arial", 1, 14)); // NOI18N
        restfulSleepLabel.setText("Was your sleep restful?");

        noRadioButton.setFont(new java.awt.Font("Arial", 1, 14)); // NOI18N
        noRadioButton.setText("No");

        yesRadioButton.setFont(new java.awt.Font("Arial", 1, 14)); // NOI18N
        yesRadioButton.setText("Yes");

        refreshedSlider.setBackground(new java.awt.Color(0, 0, 255));
        refreshedSlider.setValue(0);

        displayButton.setFont(new java.awt.Font("Segoe UI", 1, 14)); // NOI18N
        displayButton.setText("Display Data");
        displayButton.setBorder(new javax.swing.border.SoftBevelBorder(javax.swing.border.BevelBorder.RAISED));
        displayButton.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                displayButtonActionPerformed(evt);
            }
        });

        I_date.setText("0");

        I_time.setText("0");

        javax.swing.GroupLayout jPanel1Layout = new javax.swing.GroupLayout(jPanel1);
        jPanel1.setLayout(jPanel1Layout);
        jPanel1Layout.setHorizontalGroup(
            jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel1Layout.createSequentialGroup()
                .addGap(46, 46, 46)
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(jPanel1Layout.createSequentialGroup()
                        .addComponent(sleepDurationLabel)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(sleepDurationTextField1, javax.swing.GroupLayout.PREFERRED_SIZE, 281, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
                    .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel1Layout.createSequentialGroup()
                        .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                            .addGroup(jPanel1Layout.createSequentialGroup()
                                .addComponent(refreshedLabel)
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                                .addComponent(refreshedSlider, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
                            .addGroup(jPanel1Layout.createSequentialGroup()
                                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                    .addComponent(wakeUpLabel)
                                    .addComponent(restfulSleepLabel))
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                    .addGroup(jPanel1Layout.createSequentialGroup()
                                        .addComponent(yesRadioButton)
                                        .addGap(85, 85, 85)
                                        .addComponent(noRadioButton))
                                    .addComponent(wakeUpTextField, javax.swing.GroupLayout.PREFERRED_SIZE, 281, javax.swing.GroupLayout.PREFERRED_SIZE))))
                        .addGap(20, 20, 20))))
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel1Layout.createSequentialGroup()
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel1Layout.createSequentialGroup()
                        .addComponent(displayButton)
                        .addGap(38, 38, 38)
                        .addComponent(Backbtn, javax.swing.GroupLayout.PREFERRED_SIZE, 114, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addGap(52, 52, 52)
                        .addComponent(submitButton, javax.swing.GroupLayout.PREFERRED_SIZE, 98, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addGap(106, 106, 106))
                    .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel1Layout.createSequentialGroup()
                        .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING, false)
                            .addComponent(I_time, javax.swing.GroupLayout.DEFAULT_SIZE, 66, Short.MAX_VALUE)
                            .addComponent(I_date, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
                        .addGap(33, 33, 33))))
        );

        jPanel1Layout.linkSize(javax.swing.SwingConstants.HORIZONTAL, new java.awt.Component[] {refreshedLabel, restfulSleepLabel, sleepDurationLabel, wakeUpLabel});

        jPanel1Layout.linkSize(javax.swing.SwingConstants.HORIZONTAL, new java.awt.Component[] {Backbtn, displayButton, submitButton});

        jPanel1Layout.setVerticalGroup(
            jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel1Layout.createSequentialGroup()
                .addComponent(I_date)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, 8, Short.MAX_VALUE)
                .addComponent(I_time)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(sleepDurationLabel)
                    .addComponent(sleepDurationTextField1, javax.swing.GroupLayout.PREFERRED_SIZE, 52, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(28, 28, 28)
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(wakeUpLabel)
                    .addComponent(wakeUpTextField, javax.swing.GroupLayout.PREFERRED_SIZE, 52, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(28, 28, 28)
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(restfulSleepLabel)
                    .addComponent(noRadioButton)
                    .addComponent(yesRadioButton))
                .addGap(28, 28, 28)
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(refreshedLabel, javax.swing.GroupLayout.PREFERRED_SIZE, 52, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(refreshedSlider, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(29, 29, 29)
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(submitButton, javax.swing.GroupLayout.PREFERRED_SIZE, 34, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                        .addComponent(Backbtn)
                        .addComponent(displayButton)))
                .addGap(21, 21, 21))
        );

        jPanel1Layout.linkSize(javax.swing.SwingConstants.VERTICAL, new java.awt.Component[] {refreshedLabel, restfulSleepLabel, sleepDurationLabel, wakeUpLabel});

        jPanel1Layout.linkSize(javax.swing.SwingConstants.VERTICAL, new java.awt.Component[] {Backbtn, displayButton, submitButton});

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addGap(17, 17, 17)
                .addComponent(jPanel1, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addContainerGap(17, Short.MAX_VALUE))
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addGap(18, 18, 18)
                .addComponent(jPanel1, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addContainerGap())
        );

        pack();
    }// </editor-fold>//GEN-END:initComponents

    private void submitButtonActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_submitButtonActionPerformed
        String sleepDuration = sleepDurationTextField1.getText();
    String wakeUp = wakeUpTextField.getText();
    String isRestful = yesRadioButton.isSelected() ? "Yes" : "No";
    int refreshedLevel = refreshedSlider.getValue();
    String currentDate = I_date.getText();
    String currentTime = I_time.getText();

  

    try (Connection connection = DriverManager.getConnection(dbUrl, dbUsername, dbPassword)) {
        String insertQuery = "INSERT INTO sleep_records (sleep_duration, wake_up_duration, is_restful, refreshed_level, date, time) " +
                "VALUES (?, ?, ?, ?, ?, ?)";

        PreparedStatement statement = connection.prepareStatement(insertQuery);
        statement.setString(1, sleepDuration);
        statement.setString(2, wakeUp);
        statement.setString(3, isRestful);
        statement.setInt(4, refreshedLevel);
        statement.setString(5, currentDate);
        statement.setString(6, currentTime);

        int rowsAffected = statement.executeUpdate();

        if (rowsAffected > 0) {
            JOptionPane.showMessageDialog(null, "Sleep information saved successfully!");
        } else {
            JOptionPane.showMessageDialog(null, "Failed to save sleep information.");
        }
    } catch (SQLException e) {
        e.printStackTrace();
    }
    }//GEN-LAST:event_submitButtonActionPerformed

    private void BackbtnActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_BackbtnActionPerformed
       
    }//GEN-LAST:event_BackbtnActionPerformed

    private void displayButtonActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_displayButtonActionPerformed
       DataLists Datalists = new DataLists();
                Datalists.setVisible(true);
                this.dispose();
    }//GEN-LAST:event_displayButtonActionPerformed

    public void dt(){
        Date d = new Date();
        SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd");
        
        String dd =sdf.format(d);
        I_date.setText(dd);

}
      public void times() {
        Timer timer = new Timer(1000, new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                displayCurrentTime();
            }
        });
        timer.start();
    }
      private void displayCurrentTime() {
        Date currentTime = new Date();
        SimpleDateFormat sdf = new SimpleDateFormat("HH:mm:ss");
        String timeString = sdf.format(currentTime);
        I_time.setText(timeString);
    }
    public static void main(String args[]) {
        
        java.awt.EventQueue.invokeLater(new Runnable() {
            public void run() {
                new SleepTrackerFrame().setVisible(true);
            }
        });
    }

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JButton Backbtn;
    private javax.swing.JLabel I_date;
    private javax.swing.JLabel I_time;
    private javax.swing.JButton displayButton;
    private javax.swing.JPanel jPanel1;
    private javax.swing.JRadioButton noRadioButton;
    private javax.swing.JLabel refreshedLabel;
    private javax.swing.JSlider refreshedSlider;
    private javax.swing.JLabel restfulSleepLabel;
    private javax.swing.JLabel sleepDurationLabel;
    private javax.swing.JTextField sleepDurationTextField1;
    private javax.swing.JButton submitButton;
    private javax.swing.JLabel wakeUpLabel;
    private javax.swing.JTextField wakeUpTextField;
    private javax.swing.JRadioButton yesRadioButton;
    // End of variables declaration//GEN-END:variables


}
