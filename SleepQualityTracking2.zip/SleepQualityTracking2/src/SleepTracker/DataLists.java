
package SleepTracker;
import java.sql.*;
import javax.swing.JTable;
import javax.swing.table.DefaultTableModel;
public class DataLists extends javax.swing.JFrame {

    
    public DataLists() {
        initComponents();
        displayDataFromDatabase();
    }
 private void displayDataFromDatabase() {
        // Database connection details
        String dbUrl = "jdbc:mysql://localhost:3306/sqt";
    String dbUsername = "root";
    String dbPassword = "";

    try (Connection connection = DriverManager.getConnection(dbUrl, dbUsername, dbPassword)) {
        String selectQuery = "SELECT * FROM sleep_records";
        Statement statement = connection.createStatement();
        ResultSet resultSet = statement.executeQuery(selectQuery);

        DefaultTableModel model = new DefaultTableModel();
        model.addColumn("ID");
        model.addColumn("Sleep Duration");
        model.addColumn("Wake Up Duration");
        model.addColumn("Is Restful");
        model.addColumn("Refreshed Level");
        model.addColumn("Sleep Date");
        model.addColumn("Sleep Time");

        while (resultSet.next()) {
            int recordId = resultSet.getInt("id");
            String sleepDuration = resultSet.getString("sleep_duration");
            String wakeUp = resultSet.getString("wake_up_duration");
            String isRestful = resultSet.getString("is_restful");
            int refreshedLevel = resultSet.getInt("refreshed_level");
            String sleepDate = resultSet.getDate("date").toString();
            String sleepTime = resultSet.getTime("time").toString();

            model.addRow(new Object[]{recordId, sleepDuration, wakeUp, isRestful, refreshedLevel, sleepDate, sleepTime});
        }

        jTable1.setModel(model);
    } catch (SQLException e) {
        e.printStackTrace();
    }
    }
    
    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        jScrollPane1 = new javax.swing.JScrollPane();
        jTable1 = new javax.swing.JTable();
        Backbtn = new javax.swing.JButton();

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);

        jTable1.setFont(new java.awt.Font("Segoe UI", 1, 12)); // NOI18N
        jTable1.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {
                {null, null, null, null, null, null, null},
                {null, null, null, null, null, null, null},
                {null, null, null, null, null, null, null},
                {null, null, null, null, null, null, null}
            },
            new String [] {
                "Id", "Sleep", "Wake_up", "Restful", " Refreshed %", "date", "time"
            }
        ));
        jTable1.setName(""); // NOI18N
        jScrollPane1.setViewportView(jTable1);

        Backbtn.setFont(new java.awt.Font("Segoe UI", 1, 14)); // NOI18N
        Backbtn.setText("Back");
        Backbtn.setBorder(new javax.swing.border.SoftBevelBorder(javax.swing.border.BevelBorder.RAISED));
        Backbtn.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                BackbtnActionPerformed(evt);
            }
        });

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, layout.createSequentialGroup()
                .addContainerGap()
                .addComponent(jScrollPane1, javax.swing.GroupLayout.DEFAULT_SIZE, 682, Short.MAX_VALUE)
                .addContainerGap())
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, layout.createSequentialGroup()
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addComponent(Backbtn, javax.swing.GroupLayout.PREFERRED_SIZE, 114, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(277, 277, 277))
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addContainerGap()
                .addComponent(jScrollPane1, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, 21, Short.MAX_VALUE)
                .addComponent(Backbtn)
                .addContainerGap())
        );

        pack();
    }// </editor-fold>//GEN-END:initComponents

    private void BackbtnActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_BackbtnActionPerformed
SleepTrackerFrame SleepTrackerframe = new SleepTrackerFrame();
                SleepTrackerframe.setVisible(true);
                this.dispose();
    }//GEN-LAST:event_BackbtnActionPerformed

    
    public static void main(String args[]) {
       java.awt.EventQueue.invokeLater(new Runnable() {
            public void run() {
                new DataLists().setVisible(true);
            }
        });
    }

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JButton Backbtn;
    private javax.swing.JScrollPane jScrollPane1;
    private javax.swing.JTable jTable1;
    // End of variables declaration//GEN-END:variables
}
