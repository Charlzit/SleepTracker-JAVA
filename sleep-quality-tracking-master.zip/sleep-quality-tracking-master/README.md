sleep-quality-tracking
======================

This app will keep on tracking the environment light and audio thile it's opened.
The data will be saved on external memory on 

Android/data/com.apps.muhammadkhadafi.sleepqualitytracker/files/MyFileStorage/log(datetime).txt
